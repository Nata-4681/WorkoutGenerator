package org.jbltd.wgn;

public enum WorkoutType {

    BENCH, SQUAT, POWERCLEAN, SNATCH;
    
}
