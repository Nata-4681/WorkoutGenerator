package org.jbltd.wgn;

public enum WorkoutDifficulty {

    BEGINNER, NOVICE, EXPERIENCED, CROSSFIT;
    
}
